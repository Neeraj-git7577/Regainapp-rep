# Regain basic Android app

This is a newly created basic Expo app because the supplied archive contained configuration only, not the original app source.

Included: home dashboard, working 25-minute focus timer, demo distraction toggles, placeholder stats.
Not included: real app blocking, usage tracking, accessibility service, floating overlay, notifications, cloud sync.

## Build an installable APK
1. Install Node.js and run `npm install`.
2. Install EAS CLI: `npm install -g eas-cli`.
3. Sign in: `eas login`.
4. From this folder run: `eas build --platform android --profile preview`.
5. Download the APK from the build link EAS provides.

The build uses Expo's cloud builder; an Expo account is required.
