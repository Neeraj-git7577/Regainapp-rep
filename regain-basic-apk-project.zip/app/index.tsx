import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const GREEN = '#B7F36B';
export default function Home() {
  const [seconds, setSeconds] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [selected, setSelected] = useState('Home');
  const [blocked, setBlocked] = useState({ Instagram: true, 'YouTube Shorts': true, TikTok: false });
  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setSeconds(s => {
      if (s <= 1) { setRunning(false); return 0; }
      return s - 1;
    }), 1000);
    return () => clearInterval(id);
  }, [running]);
  const time = `${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;
  const reset = () => { setRunning(false); setSeconds(25*60); };
  const tabs = ['Home','Focus','Block','Stats'];
  return <View style={s.root}>
    <ScrollView contentContainerStyle={s.content}>
      <View style={s.top}><View><Text style={s.brand}>REGAIN</Text><Text style={s.sub}>TAKE BACK YOUR TIME</Text></View><View style={s.avatar}><Text style={s.avatarText}>R</Text></View></View>
      {selected === 'Home' && <>
        <LinearGradient colors={['#202A19','#171A16']} style={s.hero}>
          <Text style={s.eyebrow}>YOUR DAY, YOUR CONTROL</Text>
          <Text style={s.heroTitle}>Make today{'\n'}count.</Text>
          <Text style={s.muted}>Small steps. Better focus. More life.</Text>
          <Pressable style={s.primary} onPress={()=>setSelected('Focus')}><Text style={s.primaryText}>START FOCUS  →</Text></Pressable>
        </LinearGradient>
        <Text style={s.section}>TODAY AT A GLANCE</Text>
        <View style={s.statsRow}><View style={s.stat}><Text style={s.statNum}>0h 00m</Text><Text style={s.muted}>Screen time</Text></View><View style={s.stat}><Text style={s.statNum}>0</Text><Text style={s.muted}>Focus sessions</Text></View></View>
        <View style={s.tip}><Text style={s.tipTitle}>✦  A NOTE TO YOURSELF</Text><Text style={s.tipText}>Your attention is valuable. Spend it on what matters.</Text></View>
      </>}
      {selected === 'Focus' && <View style={s.panel}>
        <Text style={s.section}>FOCUS SESSION</Text><Text style={s.bigTime}>{time}</Text><Text style={s.muted}>25 minute focus session</Text>
        <View style={s.controls}><Pressable style={s.primary} onPress={()=>setRunning(!running)}><Text style={s.primaryText}>{running?'PAUSE':'START'}</Text></Pressable><Pressable style={s.secondary} onPress={reset}><Text style={s.secondaryText}>RESET</Text></Pressable></View>
        {seconds===0 && <Text style={s.success}>Session complete. Great work!</Text>}
      </View>}
      {selected === 'Block' && <View style={s.panel}>
        <Text style={s.section}>DISTRACTION LIST</Text><Text style={s.muted}>Choose apps you want to avoid during focus time.</Text>
        {Object.entries(blocked).map(([name,on])=><Pressable key={name} style={s.blockRow} onPress={()=>setBlocked(b=>({...b,[name]:!b[name]}))}><View><Text style={s.blockName}>{name}</Text><Text style={s.muted}>{on?'Added to your focus list':'Not on your list'}</Text></View><View style={[s.toggle,on&&s.toggleOn]}><View style={[s.knob,on&&s.knobOn]}/></View></Pressable>)}
        <Text style={s.footnote}>Demo controls only — this basic build does not technically block other apps.</Text>
      </View>}
      {selected === 'Stats' && <View style={s.panel}><Text style={s.section}>YOUR PROGRESS</Text><Text style={s.heroTitle}>A fresh start.</Text><Text style={s.muted}>Your focus history will appear here as you use the app.</Text><View style={s.stat}><Text style={s.statNum}>0 min</Text><Text style={s.muted}>Total focus time</Text></View></View>}
    </ScrollView>
    <View style={s.nav}>{tabs.map(t=><Pressable key={t} onPress={()=>setSelected(t)} style={s.navItem}><Text style={[s.navText,selected===t&&s.navActive]}>{t}</Text></Pressable>)}</View>
  </View>;
}
const s=StyleSheet.create({
 root:{flex:1,backgroundColor:'#101110'},content:{padding:22,paddingTop:58,paddingBottom:30},
 top:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:28},
 brand:{color:GREEN,fontSize:23,fontWeight:'900',letterSpacing:4},sub:{color:'#7D8379',fontSize:9,letterSpacing:2,marginTop:4},
 avatar:{width:40,height:40,borderRadius:20,backgroundColor:'#242B20',alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:'#45513A'},avatarText:{color:GREEN,fontWeight:'800'},
 hero:{padding:24,borderRadius:24,borderWidth:1,borderColor:'#35432A',marginBottom:28,minHeight:280,justifyContent:'center'},
 eyebrow:{color:GREEN,fontSize:10,fontWeight:'800',letterSpacing:2,marginBottom:16},heroTitle:{color:'#F4F5F0',fontSize:42,fontWeight:'800',lineHeight:48,marginBottom:12},muted:{color:'#92988E',fontSize:13,lineHeight:20},
 primary:{backgroundColor:GREEN,paddingVertical:15,paddingHorizontal:20,borderRadius:14,alignItems:'center',marginTop:24},primaryText:{color:'#11150D',fontWeight:'900',letterSpacing:1,fontSize:12},
 section:{color:'#AEB5A6',fontSize:11,fontWeight:'800',letterSpacing:2,marginBottom:16},
 statsRow:{flexDirection:'row',gap:12,marginBottom:18},stat:{flex:1,backgroundColor:'#1B1F1A',padding:20,borderRadius:18,borderWidth:1,borderColor:'#2B3227'},statNum:{color:'#F2F4EC',fontSize:23,fontWeight:'800',marginBottom:6},
 tip:{backgroundColor:'#1B1F1A',padding:20,borderRadius:18,borderWidth:1,borderColor:'#2B3227'},tipTitle:{color:GREEN,fontSize:10,fontWeight:'800',letterSpacing:1,marginBottom:10},tipText:{color:'#D5D9CE',fontSize:14,lineHeight:21},
 panel:{backgroundColor:'#1B1F1A',padding:22,borderRadius:22,borderWidth:1,borderColor:'#2B3227',minHeight:300},bigTime:{color:'#F4F5F0',fontSize:64,fontWeight:'800',textAlign:'center',marginTop:30},controls:{flexDirection:'row',gap:12},secondary:{flex:1,borderWidth:1,borderColor:'#51594A',padding:15,borderRadius:14,alignItems:'center',marginTop:24},secondaryText:{color:'#DCE2D3',fontWeight:'800'},success:{color:GREEN,textAlign:'center',marginTop:18,fontWeight:'700'},
 blockRow:{paddingVertical:18,borderBottomWidth:1,borderBottomColor:'#30362D',flexDirection:'row',justifyContent:'space-between',alignItems:'center'},blockName:{color:'#F0F2EA',fontWeight:'700',fontSize:15,marginBottom:4},toggle:{width:48,height:27,borderRadius:20,backgroundColor:'#42483E',padding:3,justifyContent:'center'},toggleOn:{backgroundColor:'#789B48'},knob:{width:21,height:21,borderRadius:11,backgroundColor:'#E7EADD'},knobOn:{alignSelf:'flex-end',backgroundColor:'#FFFFFF'},footnote:{color:'#8C9287',fontSize:11,lineHeight:17,marginTop:20},
 nav:{height:76,backgroundColor:'#171A16',borderTopWidth:1,borderTopColor:'#292E26',flexDirection:'row',justifyContent:'space-around',alignItems:'center'},navItem:{padding:12},navText:{color:'#777F72',fontSize:12,fontWeight:'700'},navActive:{color:GREEN}
});
